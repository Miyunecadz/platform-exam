# Starter package — Part B

This package contains sample data only. There is no code scaffolding, so you are free to use any language and structure the work however you prefer.

## What's here

```
definitions/
  client-a-city-maintenance.json     field definitions for Client A
  client-b-grant-foundation.json     field definitions for Client B
  client-c-clinic-referrals.json     field definitions for Client C

sample-records/
  client-a-records.json              submitted records for Client A
  client-b-records.json              submitted records for Client B
  client-c-records.json              submitted records for Client C
```

Each record carries a `_note` describing roughly what it is meant to exercise. Ignore `_note` when validating — it is there for you, not for your code.

## The field definition format

A definition file describes one record type belonging to one client:

```json
{
  "client": "client-c",
  "record_type": "patient_referral",
  "fields": [ ... ]
}
```

Each entry in `fields` may carry:

| Property | Meaning |
|---|---|
| `name` | The key used in submitted records |
| `label` | Human-readable label |
| `type` | One of the field types below |
| `required` | Whether a value must be present |
| `options` | Permitted values, for `choice` and `multi_choice` |
| `constraints` | Type-dependent limits — see below |
| `sensitivity` | Present on some fields |

**Field types used across the three clients:** `text`, `long_text`, `number`, `boolean`, `date`, `email`, `phone`, `choice`, `multi_choice`, `file`.

**Constraints used across the three clients:** `min`, `max`, `min_length`, `max_length`, `pattern`, `min_selected`, `max_selected`, `accepted`.

This is the format as it exists today. It is not necessarily complete or well designed — if you think something is missing or wrong, say so in your README.

## What to build

**Part 1.** Given a definition file and a submitted record, return the validation errors in a form that would be useful to whoever has to show them to a user.

**Part 2.** Given the same definition file, return a description of a form that a frontend could render — fields in order, input type, label, options, required flag. Return a data structure. Do not build a user interface.

## The constraint that matters

Your library must contain no knowledge of any specific client. No client field names, no client-specific branches, no per-client code paths.

After you submit, we will run your library against a fourth definition file you have not seen, belonging to a client that does not appear in the brief. It will use the same format and the same field types. If your code handles it without modification, you have done what the exercise asks.

## What to send back

Your code, your tests, and a README covering:

- How it works
- The decisions you made where the format left the answer open — the sample records will push you into several of these
- What you would do differently with more time
- One example of the Part 2 output

Working code that is honest about its limits beats complete code that hides them.
